                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3397089
Zoid, the Trapezoidal Under Cabinet 1.5" OLED Display by rhattie is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This is a dead simple display unit for a WaveShare 1.5" OLED module and a NodeMCU 1.0 board. No soldering required, just plug the display into the NodeMCU and screw everything together. While it's designed to mount to the underside of a cabinet, you could just as easily set it on top of a shelf, stick it to the side of a filing cabinet, or put it anywhere else you like. Just make sure to set the display orientation to match (super easy with the GFX library on the SSD1351, hopefully implemented soon with my SSD1327 library).

You will need:

| Part | Quantity |
|-------|-------------|
| NodeMCU 1.0 | x1 |
| Waveshare 1.5" OLED Module (SSD1327 or SSD1351) | x1 |
| M3x10 | x4 |
| M3x6 | x2 |
| M3x6+6 standoff (i.e. 6mm of column, 6mm of screw thread) | x2 |
| M3 nut | x6 |
| 2mm M3 spacer (or just more nuts if you don't have spacers that fit next to the display) | x4 |

If you're using the SSD1327, I've written a [bare-bones library for the Arduino ecosystem](https://github.com/hexaguin/SSD1327). It's not nearly as fully-featured as something like Adafruit's GFX library (although if somebody wants to port my library to GFX, that would be wonderful), but it does have functions to draw text, rectangles, and individual pixels, so you can still put together a decent-looking display UI with a bit of coding. Most importantly, it supports the full 16 grey levels of the SSD1327.

# Print Settings

Printer Brand: Creality
Printer: CR-10S
Rafts: No
Supports: Yes
Resolution: 0.2mm
Infill: 15%

Notes: 
Supports are only needed on the bridging of the screen bevel. I'd recommend using a slicer with decent support customization, such as Cura, Ideamaker, or Simplify3D. Slic3rPE's support blockers *should* work, but I always find them to be too much of a pain to be worth it.